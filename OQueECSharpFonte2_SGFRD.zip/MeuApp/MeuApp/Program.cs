﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeuApp
{
    class Program
    {
        static void Main(string[] args)
        {
            double media = 8;

            if (media >= 7)
            {
                Console.WriteLine("APROVADO");
            }           
            else
            {
                Console.WriteLine("REPROVADO");
            }


            Console.ReadKey();
        }
    }
}
